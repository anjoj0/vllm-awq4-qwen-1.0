/**
 * Copyright (c) NVIDIA CORPORATION & AFFILIATES, 2026. ALL RIGHTS RESERVED.
 *
 * See file LICENSE for terms.
 */


#ifndef UCP_DT_SGL_H_
#define UCP_DT_SGL_H_

#include <ucp/api/ucp.h>
#include <ucp/dt/dt.h>


#define UCP_DT_IS_SGL(_datatype) \
    (((_datatype) & UCP_DATATYPE_CLASS_MASK) == UCP_DATATYPE_SGL)


/**
 * Check that all SGL entries match the given memory info
 *
 * @param [in]     context        Context for memory detection
 * @param [in]     buffers        Array of buffer pointers to check
 * @param [in]     lengths        Array of buffer lengths
 * @param [in]     count          Number of entries in @a buffers / @a lengths
 * @param [in]     mem_info       Compare the SGL entries to this memory info
 *
 * @return UCS_OK if all SGL entries match the given memory info, otherwise
 *         return UCS_ERR_INVALID_PARAM
 */
ucs_status_t ucp_dt_sgl_check_same_mem_info(ucp_context_h context,
                                            void * const *buffers,
                                            const size_t *lengths,
                                            size_t count,
                                            const ucp_memory_info_t *mem_info);


/**
 * Check that all rkeys in an SGL map to the same remote endpoint configuration
 *
 * @param [in]     rkeys          Array of remote keys to check
 * @param [in]     count          Number of entries in the @a rkeys array
 *
 * @return UCS_OK if all rkeys share the same configuration, otherwise return
 *         UCS_ERR_INVALID_PARAM
 */
ucs_status_t ucp_dt_sgl_check_same_rkey_config(const ucp_rkey_h *rkeys,
                                               size_t count);

#endif
