/**
* Copyright (c) NVIDIA CORPORATION & AFFILIATES, 2001-2024. ALL RIGHTS RESERVED.
* Copyright (C) The University of Tennessee and The University
*               of Tennessee Research Foundation. 2015. ALL RIGHTS RESERVED.
* Copyright (C) UT-Battelle, LLC. 2015. ALL RIGHTS RESERVED.
* Copyright (C) ARM Ltd. 2017-2021.  ALL RIGHTS RESERVED.
*
* See file LICENSE for terms.
*/

#ifdef HAVE_CONFIG_H
#  include "config.h"
#endif

#include "perftest.h"

#include <ucs/sys/string.h>
#include <ucs/sys/sys.h>
#include <ucs/sys/sock.h>
#include <ucs/debug/log.h>
#include <ucs/sys/iovec.inl>

#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/poll.h>


test_type_t tests[] = {
    {"am_lat", UCX_PERF_API_UCT, UCX_PERF_CMD_AM, UCX_PERF_TEST_TYPE_PINGPONG,
     "active message latency", "latency", 1},

    {"put_lat", UCX_PERF_API_UCT, UCX_PERF_CMD_PUT, UCX_PERF_TEST_TYPE_PINGPONG,
     "put latency", "latency", 1},

    {"add_lat", UCX_PERF_API_UCT, UCX_PERF_CMD_ADD, UCX_PERF_TEST_TYPE_PINGPONG,
     "atomic add latency", "latency", 1},

    {"get", UCX_PERF_API_UCT, UCX_PERF_CMD_GET, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "get latency / bandwidth / message rate", "latency", 1},

    {"fadd", UCX_PERF_API_UCT, UCX_PERF_CMD_FADD, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "atomic fetch-and-add latency / rate", "latency", 1},

    {"swap", UCX_PERF_API_UCT, UCX_PERF_CMD_SWAP, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "atomic swap latency / rate", "latency", 1},

    {"cswap", UCX_PERF_API_UCT, UCX_PERF_CMD_CSWAP, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "atomic compare-and-swap latency / rate", "latency", 1},

    {"am_bw", UCX_PERF_API_UCT, UCX_PERF_CMD_AM, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "active message bandwidth / message rate", "overhead", 1},

    {"put_bw", UCX_PERF_API_UCT, UCX_PERF_CMD_PUT, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "put bandwidth / message rate", "overhead", 32},

    {"get_bw", UCX_PERF_API_UCT, UCX_PERF_CMD_GET, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "get bandwidth / message rate", "overhead", 32},

    {"add_mr", UCX_PERF_API_UCT, UCX_PERF_CMD_ADD, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "atomic add message rate", "overhead", 1},

    {"tag_lat", UCX_PERF_API_UCP, UCX_PERF_CMD_TAG, UCX_PERF_TEST_TYPE_PINGPONG,
     "tag match latency", "latency", 1},

    {"tag_bw", UCX_PERF_API_UCP, UCX_PERF_CMD_TAG, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "tag match bandwidth", "overhead", 32},

    {"tag_sync_lat", UCX_PERF_API_UCP, UCX_PERF_CMD_TAG_SYNC, UCX_PERF_TEST_TYPE_PINGPONG,
     "tag sync match latency", "latency", 1},

    {"tag_sync_bw", UCX_PERF_API_UCP, UCX_PERF_CMD_TAG_SYNC, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "tag sync match bandwidth", "overhead", 32},

    {"ucp_put_lat", UCX_PERF_API_UCP, UCX_PERF_CMD_PUT, UCX_PERF_TEST_TYPE_PINGPONG,
     "put latency", "latency", 1},

    {"ucp_put_bw", UCX_PERF_API_UCP, UCX_PERF_CMD_PUT, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "put bandwidth", "overhead", 32},

    {"ucp_get", UCX_PERF_API_UCP, UCX_PERF_CMD_GET, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "get latency / bandwidth / message rate", "latency", 1},

    {"ucp_add", UCX_PERF_API_UCP, UCX_PERF_CMD_ADD, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "atomic add bandwidth / message rate", "overhead", 1},

    {"ucp_fadd", UCX_PERF_API_UCP, UCX_PERF_CMD_FADD, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "atomic fetch-and-add latency / bandwidth / rate", "latency", 1},

    {"ucp_swap", UCX_PERF_API_UCP, UCX_PERF_CMD_SWAP, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "atomic swap latency / bandwidth / rate", "latency", 1},

    {"ucp_cswap", UCX_PERF_API_UCP, UCX_PERF_CMD_CSWAP, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "atomic compare-and-swap latency / bandwidth / rate", "latency", 1},

    {"stream_bw", UCX_PERF_API_UCP, UCX_PERF_CMD_STREAM, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "stream bandwidth", "overhead", 1},

    {"stream_lat", UCX_PERF_API_UCP, UCX_PERF_CMD_STREAM, UCX_PERF_TEST_TYPE_PINGPONG,
     "stream latency", "latency", 1},

    {"ucp_am_lat", UCX_PERF_API_UCP, UCX_PERF_CMD_AM, UCX_PERF_TEST_TYPE_PINGPONG,
     "am latency", "latency", 1},

    {"ucp_am_bw", UCX_PERF_API_UCP, UCX_PERF_CMD_AM, UCX_PERF_TEST_TYPE_STREAM_UNI,
     "am bandwidth / message rate", "overhead", 32},

    {NULL}
};

static int sock_io(int sock, ssize_t (*sock_call)(int, void *, size_t, int),
                   int poll_events, void *data, size_t size,
                   void (*progress)(void *arg), void *arg, const char *name)
{
    size_t total = 0;
    struct pollfd pfd;
    int ret;

    while (total < size) {
        pfd.fd      = sock;
        pfd.events  = poll_events;
        pfd.revents = 0;

        ret = poll(&pfd, 1, 1); /* poll for 1ms */
        if (ret > 0) {
            ucs_assert(ret == 1);
            ucs_assert(pfd.revents & poll_events);

            ret = sock_call(sock, (char*)data + total, size - total, 0);
            if ((ret == 0) && (poll_events & POLLIN)) {
                ucs_error("%s() remote closed connection", name);
                return -1;
            }
            if (ret < 0) {
                ucs_error("%s() failed: %m", name);
                return -1;
            }
            total += ret;
        } else if ((ret < 0) && (errno != EINTR)) {
            ucs_error("poll(fd=%d) failed: %m", sock);
            return -1;
        }

        /* progress user context */
        if (progress != NULL) {
            progress(arg);
        }
    }
    return 0;
}

static int safe_send(int sock, void *data, size_t size,
                     void (*progress)(void *arg), void *arg)
{
    typedef ssize_t (*sock_call)(int, void *, size_t, int);

    ucs_assert(sock >= 0);
    return sock_io(sock, (sock_call)send, POLLOUT, data, size, progress, arg, "send");
}

static int safe_recv(int sock, void *data, size_t size,
                     void (*progress)(void *arg), void *arg)
{
    ucs_assert(sock >= 0);
    return sock_io(sock, recv, POLLIN, data, size, progress, arg, "recv");
}

ucs_status_t init_test_params(perftest_params_t *params)
{
    static const struct sockaddr_storage empty_addr = {};
    static const ucx_perf_accel_dev_t default_dev   =
                            {UCS_MEMORY_TYPE_LAST, UCX_PERF_MEM_DEV_DEFAULT};

    memset(params, 0, sizeof(*params));
    params->super.api                 = UCX_PERF_API_LAST;
    params->super.command             = UCX_PERF_CMD_LAST;
    params->super.test_type           = UCX_PERF_TEST_TYPE_LAST;
    params->super.thread_mode         = UCS_THREAD_MODE_SERIALIZED;
    params->super.thread_count        = 1;
    params->super.async_mode          = UCS_ASYNC_THREAD_LOCK_TYPE;
    params->super.wait_mode           = UCX_PERF_WAIT_MODE_LAST;
    params->super.max_outstanding     = 0;
    params->super.warmup_iter         = 10000;
    params->super.warmup_time         = 100e-3;
    params->super.alignment           = ucs_get_page_size();
    params->super.max_iter            = 1000000l;
    params->super.max_time            = 0.0;
    params->super.report_interval     = 1.0;
    params->super.percentile_rank     = 50.0;
    params->super.flags               = UCX_PERF_TEST_FLAG_VERBOSE;
    params->super.uct.fc_window       = UCT_PERF_TEST_MAX_FC_WINDOW;
    params->super.uct.data_layout     = UCT_PERF_DATA_LAYOUT_SHORT;
    params->super.uct.am_hdr_size     = 8;
    params->super.send_mem_type       = UCS_MEMORY_TYPE_HOST;
    params->super.recv_mem_type       = UCS_MEMORY_TYPE_HOST;
    params->super.send_device         = default_dev;
    params->super.recv_device         = default_dev;
    params->super.device_level        = UCS_DEVICE_LEVEL_THREAD;
    params->super.msg_size_cnt        = 1;
    params->super.iov_stride          = 0;
    params->super.ucp.send_datatype   = UCP_PERF_DATATYPE_CONTIG;
    params->super.ucp.recv_datatype   = UCP_PERF_DATATYPE_CONTIG;
    params->super.ucp.am_hdr_size     = 0;
    params->super.ucp.err_mode        = UCP_ERR_HANDLING_MODE_NONE;
    params->super.device_channel_mode = UCX_PERF_CHANNEL_MODE_SINGLE;
    params->super.channel_rand_seed   = ucs_generate_uuid((uintptr_t)params);
    params->super.device_thread_count = 1;
    params->super.device_block_count  = 1;
    params->super.device_fc_window    = UCP_PERF_FC_WINDOW_DEFAULT;
    params->super.ucp.is_daemon_mode  = 0;
    params->super.ucp.dmn_local_addr  = empty_addr;
    params->super.ucp.dmn_remote_addr = empty_addr;
    strcpy(params->super.uct.dev_name, TL_RESOURCE_NAME_NONE);
    strcpy(params->super.uct.tl_name,  TL_RESOURCE_NAME_NONE);

    params->super.msg_size_list = calloc(params->super.msg_size_cnt,
                                         sizeof(*params->super.msg_size_list));
    if (params->super.msg_size_list == NULL) {
        return UCS_ERR_NO_MEMORY;
    }

    params->super.msg_size_list[0] = 8;
    params->test_id                = TEST_ID_UNDEFINED;

    return UCS_OK;
}

static unsigned sock_rte_group_size(void *rte_group)
{
    sock_rte_group_t *group = rte_group;
    return group->size;
}

static unsigned sock_rte_group_index(void *rte_group)
{
    sock_rte_group_t *group = rte_group;
    return group->is_server ? 0 : 1;
}

static void sock_rte_barrier(void *rte_group, void (*progress)(void *arg),
                             void *arg)
{
#if _OPENMP
#  pragma omp barrier
#  pragma omp master
#endif
  {
    sock_rte_group_t *group = rte_group;

    if (group->size > 1) {
        const unsigned magic = 0xdeadbeef;
        unsigned snc;

        snc = magic;
        safe_send(group->sendfd, &snc, sizeof(unsigned), progress, arg);

        snc = 0;

        if (safe_recv(group->recvfd, &snc, sizeof(unsigned), progress, arg) == 0) {
            ucs_assert(snc == magic);
        } else {
            ucs_error("sock: rte barrier remote peer failure");
            exit(EXIT_FAILURE);
        }
    }
  }

#if _OPENMP
#  pragma omp barrier
#endif
}

static void sock_rte_post_vec(void *rte_group, const struct iovec *iovec,
                              int iovcnt, void **req)
{
    sock_rte_group_t *group = rte_group;
    size_t size             = ucs_iovec_total_length(iovec, iovcnt);
    int i;

    safe_send(group->sendfd, &size, sizeof(size), NULL, NULL);
    for (i = 0; i < iovcnt; ++i) {
        safe_send(group->sendfd, iovec[i].iov_base, iovec[i].iov_len, NULL,
                  NULL);
    }
}

static void sock_rte_recv(void *rte_group, unsigned src, void *buffer,
                          size_t max, void *req)
{
    sock_rte_group_t *group = rte_group;
    size_t size             = 0;
    int ret;

    if (src != group->peer) {
        return;
    }

    ret = safe_recv(group->recvfd, &size, sizeof(size), NULL, NULL);
    if (ret != 0) {
        goto err;
    }

    ucs_assert_always(size <= max);
    ret = safe_recv(group->recvfd, buffer, size, NULL, NULL);
    if (ret != 0) {
        goto err;
    }

    return;
err:
    ucs_error("sock: rte recv: remote peer failure");
    exit(EXIT_FAILURE);
}

static ucs_status_t sock_rte_setup(void *arg);
static void sock_rte_cleanup(void *arg);

static ucx_perf_rte_t sock_rte = {
    .setup        = sock_rte_setup,
    .cleanup      = sock_rte_cleanup,
    .group_size   = sock_rte_group_size,
    .group_index  = sock_rte_group_index,
    .barrier      = sock_rte_barrier,
    .post_vec     = sock_rte_post_vec,
    .recv         = sock_rte_recv,
    .exchange_vec = (ucx_perf_rte_exchange_vec_func_t)ucs_empty_function,
};

static ucs_status_t setup_sock_rte_loopback(struct perftest_context *ctx)
{
    int connfds[2];
    int ret;

    ctx->flags |= TEST_FLAG_PRINT_TEST | TEST_FLAG_PRINT_RESULTS;

    ret = socketpair(AF_UNIX, SOCK_STREAM, 0, connfds);
    if (ret < 0) {
        ucs_error("socketpair() failed: %m");
        return UCS_ERR_IO_ERROR;
    }

    ctx->sock_rte_group.peer      =  0;
    ctx->sock_rte_group.size      =  1;
    ctx->sock_rte_group.is_server =  1;
    ctx->sock_rte_group.sendfd    = connfds[0];
    ctx->sock_rte_group.recvfd    = connfds[1];

    return UCS_OK;
}

static ucs_status_t setup_sock_rte_p2p(struct perftest_context *ctx)
{
    int optval = 1;
    int sockfd = -1;
    char addr_str[UCS_SOCKADDR_STRING_LEN];
    struct sockaddr_storage client_addr;
    socklen_t client_addr_len;
    int connfd;
    struct addrinfo hints, *res, *t;
    ucs_status_t status;
    int ret;
    char service[8];
    char err_str[64];
    perftest_params_t peer_params;

    ucs_snprintf_safe(service, sizeof(service), "%u", ctx->port);
    memset(&hints, 0, sizeof(hints));
    hints.ai_flags    = (ctx->server_addr == NULL) ? AI_PASSIVE : 0;
    hints.ai_family   = ctx->af;
    hints.ai_socktype = SOCK_STREAM;

    ret = getaddrinfo(ctx->server_addr, service, &hints, &res);
    if (ret < 0) {
        ucs_error("getaddrinfo(server:%s, port:%s) error: [%s]",
                  ctx->server_addr, service, gai_strerror(ret));
        status = UCS_ERR_IO_ERROR;
        goto out;
    }

    if (res == NULL) {
        snprintf(err_str, 64, "getaddrinfo() returned empty list");
    }

    for (t = res; t != NULL; t = t->ai_next) {
        sockfd = socket(t->ai_family, t->ai_socktype, t->ai_protocol);
        if (sockfd < 0) {
            snprintf(err_str, 64, "socket() failed: %m");
            continue;
        }

        if (ctx->server_addr != NULL) {
            if (connect(sockfd, t->ai_addr, t->ai_addrlen) == 0) {
                break;
            }
            snprintf(err_str, 64, "connect() failed: %m");
        } else {
            status = ucs_socket_setopt(sockfd, SOL_SOCKET, SO_REUSEADDR,
                                       &optval, sizeof(optval));
            if (status != UCS_OK) {
                status = UCS_ERR_IO_ERROR;
                goto err_close_sockfd;
            }

            if (bind(sockfd, t->ai_addr, t->ai_addrlen) == 0) {
                ret = listen(sockfd, 10);
                if (ret < 0) {
                    ucs_error("listen() failed: %m");
                    status = UCS_ERR_IO_ERROR;
                    goto err_close_sockfd;
                }

                printf("Waiting for connection...\n");

                /* Accept next connection */
                client_addr_len = sizeof(client_addr);
                connfd          = accept(sockfd, (struct sockaddr*)&client_addr,
                                         &client_addr_len);
                if (connfd < 0) {
                    ucs_error("accept() failed: %m");
                    status = UCS_ERR_IO_ERROR;
                    goto err_close_sockfd;
                }

                ucs_sockaddr_str((struct sockaddr*)&client_addr, addr_str,
                                 sizeof(addr_str));
                printf("Accepted connection from %s\n", addr_str);
                close(sockfd);
                break;
            }
            snprintf(err_str, 64, "bind() failed: %m");
        }
        close(sockfd);
        sockfd = -1;
    }

    if (sockfd < 0) {
        ucs_error("%s failed. %s",
                  (ctx->server_addr != NULL) ? "client" : "server", err_str);
        status = UCS_ERR_IO_ERROR;
        goto out_free_res;
    }

    if (ctx->server_addr == NULL) {
        ret = safe_recv(connfd, &peer_params, sizeof(peer_params), NULL, NULL);
        if (ret) {
            status = UCS_ERR_IO_ERROR;
            goto err_close_connfd;
        }

        if (peer_params.super.msg_size_cnt != 0) {
            peer_params.super.msg_size_list =
                    calloc(peer_params.super.msg_size_cnt,
                           sizeof(*peer_params.super.msg_size_list));
            if (peer_params.super.msg_size_list == NULL) {
                status = UCS_ERR_NO_MEMORY;
                goto err_close_connfd;
            }

            ret = safe_recv(connfd, peer_params.super.msg_size_list,
                            sizeof(*peer_params.super.msg_size_list) *
                            peer_params.super.msg_size_cnt,
                            NULL, NULL);
            if (ret) {
                perftest_params_release_msg_size_list(&peer_params);
                status = UCS_ERR_IO_ERROR;
                goto err_close_connfd;
            }
        }

        status = perftest_params_merge(&ctx->params, &peer_params);
        perftest_params_release_msg_size_list(&peer_params);
        if (status != UCS_OK) {
            goto err_close_connfd;
        }

        ctx->sock_rte_group.sendfd    = connfd;
        ctx->sock_rte_group.recvfd    = connfd;
        ctx->sock_rte_group.peer      = 1;
        ctx->sock_rte_group.is_server = 1;
    } else {
        safe_send(sockfd, &ctx->params, sizeof(ctx->params), NULL, NULL);
        if (ctx->params.super.msg_size_cnt != 0) {
            safe_send(sockfd, ctx->params.super.msg_size_list,
                      sizeof(*ctx->params.super.msg_size_list) *
                      ctx->params.super.msg_size_cnt,
                      NULL, NULL);
        }

        ctx->sock_rte_group.sendfd     = sockfd;
        ctx->sock_rte_group.recvfd     = sockfd;
        ctx->sock_rte_group.peer       = 0;
        ctx->sock_rte_group.is_server  = 0;
    }

    ctx->sock_rte_group.size = 2;

    if (ctx->sock_rte_group.is_server) {
        ctx->flags |= TEST_FLAG_PRINT_TEST;
    } else {
        ctx->flags |= TEST_FLAG_PRINT_RESULTS;
    }

    status = UCS_OK;
    goto out_free_res;

err_close_connfd:
    ucs_close_fd(&connfd);
    goto out_free_res;
err_close_sockfd:
    ucs_close_fd(&sockfd);
out_free_res:
    freeaddrinfo(res);
out:
    return status;
}

static ucs_status_t sock_rte_setup(void *arg)
{
    struct perftest_context *ctx = arg;
    ucs_status_t status;

    if (ctx->params.super.flags & UCX_PERF_TEST_FLAG_LOOPBACK) {
        status = setup_sock_rte_loopback(ctx);
    } else {
        status = setup_sock_rte_p2p(ctx);
    }

    if (status != UCS_OK) {
        return status;
    }

    ctx->params.super.rte_group  = &ctx->sock_rte_group;
    ctx->params.super.rte        = &sock_rte;

    return UCS_OK;
}

static void sock_rte_cleanup(void *arg)
{
    struct perftest_context *ctx = arg;
    sock_rte_group_t *rte_group  = &ctx->sock_rte_group;

    close(rte_group->sendfd);

    if (rte_group->sendfd != rte_group->recvfd) {
        close(rte_group->recvfd);
    }
}

#if defined (HAVE_MPI)

#define MPI_RTE_BSEND_BUFFER_SIZE 4096

static unsigned mpi_rte_group_size(void *rte_group)
{
    int size;
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    return size;
}

static unsigned mpi_rte_group_index(void *rte_group)
{
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    return rank;
}

static void mpi_rte_barrier(void *rte_group, void (*progress)(void *arg),
                            void *arg)
{
    int group_size, my_rank, i;
    MPI_Request *reqs;
    int nreqs = 0;
    int dummy;
    int flag;

#pragma omp barrier

#pragma omp master
  {
    /*
     * Naive non-blocking barrier implementation over send/recv, to call user
     * progress while waiting for completion.
     * Not using MPI_Ibarrier to be compatible with MPI-1.
     */

    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &group_size);

    /* allocate maximal possible number of requests */
    reqs = (MPI_Request*)alloca(sizeof(*reqs) * group_size);

    if (my_rank == 0) {
        /* root gathers "ping" from all other ranks */
        for (i = 1; i < group_size; ++i) {
            MPI_Irecv(&dummy, 0, MPI_INT,
                      i /* source */,
                      1 /* tag */,
                      MPI_COMM_WORLD,
                      &reqs[nreqs++]);
        }
    } else {
        /* every non-root rank sends "ping" and waits for "pong" */
        MPI_Send(&dummy, 0, MPI_INT,
                 0 /* dest */,
                 1 /* tag */,
                 MPI_COMM_WORLD);
        MPI_Irecv(&dummy, 0, MPI_INT,
                  0 /* source */,
                  2 /* tag */,
                  MPI_COMM_WORLD,
                  &reqs[nreqs++]);
    }

    /* Waiting for receive requests */
    do {
        MPI_Testall(nreqs, reqs, &flag, MPI_STATUSES_IGNORE);
        progress(arg);
    } while (!flag);

    if (my_rank == 0) {
        /* root sends "pong" to all ranks */
        for (i = 1; i < group_size; ++i) {
            MPI_Send(&dummy, 0, MPI_INT,
                     i /* dest */,
                     2 /* tag */,
                     MPI_COMM_WORLD);
       }
    }
  }
#pragma omp barrier
}

static void mpi_rte_post_vec(void *rte_group, const struct iovec *iovec,
                             int iovcnt, void **req)
{
    size_t total_length = ucs_iovec_total_length(iovec, iovcnt);
    int group_size;
    int my_rank;
    int dest, i;

    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &group_size);

    ucs_assertv_always(total_length <= MPI_RTE_BSEND_BUFFER_SIZE,
                       "total_length=%zu", total_length);

    for (dest = 0; dest < group_size; ++dest) {
        if (dest != rte_peer_index(group_size, my_rank)) {
            continue;
        }

        for (i = 0; i < iovcnt; ++i) {
            MPI_Bsend(iovec[i].iov_base, iovec[i].iov_len, MPI_BYTE, dest,
                      i == (iovcnt - 1), /* Send last iov with tag == 1 */
                      MPI_COMM_WORLD);
        }
    }

    *req = (void*)(uintptr_t)1;
}

static void mpi_rte_recv(void *rte_group, unsigned src, void *buffer, size_t max,
                         void *req)
{
    MPI_Status status;
    int my_rank, size;
    size_t offset;
    int count;

    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (src != rte_peer_index(size, my_rank)) {
        return;
    }

    offset = 0;
    do {
        ucs_assert_always(offset < max);
        MPI_Recv(buffer + offset, max - offset, MPI_BYTE, src, MPI_ANY_TAG,
                 MPI_COMM_WORLD, &status);
        MPI_Get_count(&status, MPI_BYTE, &count);
        offset += count;
    } while (status.MPI_TAG != 1);
}

static ucs_status_t mpi_rte_setup(void *arg);
static void mpi_rte_cleanup(void *arg);

static ucx_perf_rte_t mpi_rte = {
    .setup        = mpi_rte_setup,
    .cleanup      = mpi_rte_cleanup,
    .group_size   = mpi_rte_group_size,
    .group_index  = mpi_rte_group_index,
    .barrier      = mpi_rte_barrier,
    .post_vec     = mpi_rte_post_vec,
    .recv         = mpi_rte_recv,
    .exchange_vec = (void*)ucs_empty_function,
};

static ucs_status_t mpi_rte_setup(void *arg)
{
    struct perftest_context *ctx = arg;
    int size, rank;
    void *buffer;

    if (!ctx->mpi) {
        return UCS_ERR_UNSUPPORTED;
    }

    ucs_trace_func("");

    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if ((ctx->params.super.flags & UCX_PERF_TEST_FLAG_LOOPBACK) &&
        (size != 1)) {
        ucs_error("This test should be run with 1 process "
                  "in loopback case (actual: %d)", size);
        return UCS_ERR_INVALID_PARAM;
    }

    if (!(ctx->params.super.flags & UCX_PERF_TEST_FLAG_LOOPBACK) &&
        (size != 2)) {
        ucs_error("This test should be run with exactly 2 processes "
                  "in p2p case (actual: %d)", size);
        return UCS_ERR_INVALID_PARAM;
    }

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    buffer = calloc(1, MPI_RTE_BSEND_BUFFER_SIZE);
    if (buffer == NULL) {
        ucs_error("failed to allocate memory for MPI_Buffer_attach");
        return UCS_ERR_NO_MEMORY;
    }
    MPI_Buffer_attach(buffer, MPI_RTE_BSEND_BUFFER_SIZE);

    /* Let the last rank print the results */
    if (rank == (size - 1)) {
        ctx->flags |= TEST_FLAG_PRINT_RESULTS;
    }

    ctx->params.super.rte_group  = NULL;
    ctx->params.super.rte        = &mpi_rte;
    return UCS_OK;
}

static void mpi_rte_cleanup(void *UCS_V_UNUSED arg)
{
    void *buffer;
    int size;

    MPI_Buffer_detach(&buffer, &size);
    ucs_assert(buffer != NULL);
    ucs_assertv(size == MPI_RTE_BSEND_BUFFER_SIZE, "size=%d", size);
    free(buffer);
}

#endif /* defined (HAVE_MPI) */

static ucs_status_t check_system(struct perftest_context *ctx)
{
    ucs_sys_cpuset_t cpuset;
    unsigned i, count, nr_cpus;
    int ret;

    ucs_trace_func("");

    ret = ucs_sys_get_num_cpus();
    if (ret < 0) {
        return UCS_ERR_INVALID_PARAM;
    }
    nr_cpus = ret;

    memset(&cpuset, 0, sizeof(cpuset));
    if (ctx->flags & TEST_FLAG_SET_AFFINITY) {
        for (i = 0; i < ctx->num_cpus; i++) {
            if (ctx->cpus[i] >= nr_cpus) {
                ucs_error("cpu (%u) out of range [0..%u]", ctx->cpus[i],
                          nr_cpus - 1);
                return UCS_ERR_INVALID_PARAM;
            }
        }

        for (i = 0; i < ctx->num_cpus; i++) {
            CPU_SET(ctx->cpus[i], &cpuset);
        }

        ret = ucs_sys_setaffinity(&cpuset);
        if (ret) {
            ucs_warn("sched_setaffinity() failed: %m");
            return UCS_ERR_INVALID_PARAM;
        }
    } else {
        ret = ucs_sys_getaffinity(&cpuset);
        if (ret) {
            ucs_warn("sched_getaffinity() failed: %m");
            return UCS_ERR_INVALID_PARAM;
        }

        count = 0;
        for (i = 0; i < CPU_SETSIZE; ++i) {
            if (CPU_ISSET(i, &cpuset)) {
                ++count;
            }
        }
        if (count > 2) {
            ucs_warn("CPU affinity is not set (bound to %u cpus)."
                     " Performance may be impacted.", count);
        }
    }

    return UCS_OK;
}

static void ctx_free(struct perftest_context *ctx)
{
    free(ctx->params.super.msg_size_list);
}

UCS_LIST_HEAD(rte_list);

static void initialize_plugins(void)
{
#if defined (HAVE_MPI)
    ucs_list_add_tail(&rte_list, &mpi_rte.list);
#endif
    ucs_list_add_tail(&rte_list, &sock_rte.list);
}

static ucs_status_t setup_rte(struct perftest_context *ctx)
{
    ucs_status_t status;
    ucx_perf_rte_t *entry;

    ucs_list_for_each(entry, &rte_list, list) {
        status = entry->setup(ctx);
        if (status != UCS_ERR_UNSUPPORTED) {
            return status;
        }
    }

    ucs_error("No supported RTE found");
    return UCS_ERR_UNSUPPORTED;
}

static void cleanup_rte(struct perftest_context *ctx)
{
    ctx->params.super.rte->cleanup(ctx);
}

int main(int argc, char **argv)
{
    struct perftest_context ctx;
    ucs_status_t status;
    int mpi_initialized;
    int ret;

#ifdef HAVE_MPI
    int provided;

    mpi_initialized = !isatty(0) &&
                      /* Using MPI_THREAD_FUNNELED since ucx_perftest supports
                       * using multiple threads when only the main one makes
                       * MPI calls (which is also suitable for a single threaded
                       * run).
                       * MPI_THREAD_FUNNELED:
                       * The process may be multi-threaded, but only the main
                       * thread will make MPI calls (all MPI calls are funneled
                       * to the main thread). */
                      (MPI_Init_thread(&argc, &argv, MPI_THREAD_FUNNELED, &provided) == 0);

    if (mpi_initialized && (provided != MPI_THREAD_FUNNELED)) {
        printf("MPI_Init_thread failed to set MPI_THREAD_FUNNELED. (provided = %d)\n",
               provided);
        ret = -1;
        goto out;
    }
#else
    mpi_initialized = 0;
#endif

    initialize_plugins();

    /* Parse command line */
    status = parse_opts(&ctx, mpi_initialized, argc, argv);
    if (status != UCS_OK) {
        ret = (status == UCS_ERR_CANCELED) ? 0 : -127;
        goto out;
    }

    status = check_system(&ctx);
    if (status != UCS_OK) {
        ret = -1;
        goto out_msg_size_list;
    }

    status = setup_rte(&ctx);
    if (status != UCS_OK) {
        ucs_error("failed to setup RTE transport: %s",
                  ucs_status_string(status));
        ret = -1;
        goto out_msg_size_list;
    }

    /* Run the test */
    status = run_test(&ctx);
    if (status != UCS_OK) {
        ret = -1;
        goto out_cleanup_rte;
    }

    ret = 0;

out_cleanup_rte:
    cleanup_rte(&ctx);
out_msg_size_list:
    ctx_free(&ctx);
out:
    if (mpi_initialized) {
#ifdef HAVE_MPI
        MPI_Finalize();
#endif
    }
    return ret;
}
