# Nowcast3D Long-Document Sanity Result

- Run ID: `20260801T160935Z_main_v2_target_only_triton_tp4_8k_rep2_8k_core`
- Config label: `main_v2_target_only_triton_tp4_8k_rep2`
- Model: `Qwen3.6-27B-AWQ4`
- Profile: `8k`
- Context mode: `evidence`
- Completed: 1/1

## Aggregate

| Metric | Value |
|---|---:|
| QA score | 4.00/4.00 |
| QA score fraction | 100.00% |
| JSON success | 100.00% |
| Citation validity | 100.00% |
| Evidence support | 100.00% |
| Source accuracy | 100.00% |
| Numeric exact match | 0.00% |
| Needle exact match | 0.00% |
| Abstention accuracy | 0.00% |
| Mean wall time | 13.103 s |
| Mean TTFT | 3.911 s |

## Cases

| Case | Type | Prompt tokens | Position | Score | JSON | Citation | Wall (s) |
|---|---|---:|---:|---:|---|---:|---:|
| n3d_fact_001_fields | single_fact | 8002 | 10.0% | 4.00/4 | yes | 100% | 13.103 |

This is a fixed small-sample engineering regression suite. It is not a replacement for a full academic long-context benchmark.
