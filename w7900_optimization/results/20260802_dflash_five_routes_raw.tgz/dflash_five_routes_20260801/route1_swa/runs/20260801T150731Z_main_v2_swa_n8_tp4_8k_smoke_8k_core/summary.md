# Nowcast3D Long-Document Sanity Result

- Run ID: `20260801T150731Z_main_v2_swa_n8_tp4_8k_smoke_8k_core`
- Config label: `main_v2_swa_n8_tp4_8k_smoke`
- Model: `Qwen3.6-27B-AWQ4`
- Profile: `8k`
- Context mode: `evidence`
- Completed: 1/1

## Aggregate

| Metric | Value |
|---|---:|
| QA score | 0.00/4.00 |
| QA score fraction | 0.00% |
| JSON success | 0.00% |
| Citation validity | 0.00% |
| Evidence support | 0.00% |
| Source accuracy | 0.00% |
| Numeric exact match | 0.00% |
| Needle exact match | 0.00% |
| Abstention accuracy | 0.00% |
| Mean wall time | 72.534 s |
| Mean TTFT | 4.099 s |

## Cases

| Case | Type | Prompt tokens | Position | Score | JSON | Citation | Wall (s) |
|---|---|---:|---:|---:|---|---:|---:|
| n3d_fact_001_fields | single_fact | 8002 | 10.0% | 0.00/4 | no | 0% | 72.534 |

This is a fixed small-sample engineering regression suite. It is not a replacement for a full academic long-context benchmark.
