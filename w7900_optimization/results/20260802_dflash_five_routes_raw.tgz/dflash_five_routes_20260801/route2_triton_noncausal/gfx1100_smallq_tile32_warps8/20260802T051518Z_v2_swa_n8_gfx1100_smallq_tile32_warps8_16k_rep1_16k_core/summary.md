# Nowcast3D Long-Document Sanity Result

- Run ID: `20260802T051518Z_v2_swa_n8_gfx1100_smallq_tile32_warps8_16k_rep1_16k_core`
- Config label: `v2_swa_n8_gfx1100_smallq_tile32_warps8_16k_rep1`
- Model: `Qwen3.6-27B-AWQ4`
- Profile: `16k`
- Context mode: `evidence`
- Completed: 1/1

## Aggregate

| Metric | Value |
|---|---:|
| QA score | 4.00/4.00 |
| QA score fraction | 100.00% |
| JSON success | 100.00% |
| Citation validity | 100.00% |
| Evidence support | 100.00% |
| Source accuracy | 100.00% |
| Numeric exact match | 0.00% |
| Needle exact match | 0.00% |
| Abstention accuracy | 0.00% |
| Mean wall time | 19.474 s |
| Mean TTFT | 10.533 s |

## Cases

| Case | Type | Prompt tokens | Position | Score | JSON | Citation | Wall (s) |
|---|---|---:|---:|---:|---|---:|---:|
| n3d_fact_001_fields | single_fact | 16002 | 10.0% | 4.00/4 | yes | 100% | 19.474 |

This is a fixed small-sample engineering regression suite. It is not a replacement for a full academic long-context benchmark.
