# Nowcast3D Long-Document Sanity Result

- Run ID: `20260801T155746Z_main_v2_swa_all_rocm_n8_tp4_16k_rep2_16k_core`
- Config label: `main_v2_swa_all_rocm_n8_tp4_16k_rep2`
- Model: `Qwen3.6-27B-AWQ4`
- Profile: `16k`
- Context mode: `evidence`
- Completed: 1/1

## Aggregate

| Metric | Value |
|---|---:|
| QA score | 4.00/4.00 |
| QA score fraction | 100.00% |
| JSON success | 100.00% |
| Citation validity | 100.00% |
| Evidence support | 100.00% |
| Source accuracy | 100.00% |
| Numeric exact match | 0.00% |
| Needle exact match | 0.00% |
| Abstention accuracy | 0.00% |
| Mean wall time | 19.123 s |
| Mean TTFT | 6.493 s |

## Cases

| Case | Type | Prompt tokens | Position | Score | JSON | Citation | Wall (s) |
|---|---|---:|---:|---:|---|---:|---:|
| n3d_fact_001_fields | single_fact | 16002 | 10.0% | 4.00/4 | yes | 100% | 19.123 |

This is a fixed small-sample engineering regression suite. It is not a replacement for a full academic long-context benchmark.
